module.exports = {
  clearMocks: true,
  coverageDirectory: '.coverage',
  testEnvironment: 'node',
}
